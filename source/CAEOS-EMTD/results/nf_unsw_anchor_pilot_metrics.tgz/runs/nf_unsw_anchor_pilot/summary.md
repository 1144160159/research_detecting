# Nested anchor/conflict gate summary

| Suite | Runs | New AUROC | Old AUROC | Delta | W/T/L | Selection accuracy | Regret |
|---|---:|---:|---:|---:|---:|---:|---:|
| nf_unsw | 6 | 0.708771 | 0.708771 | +0.000000 | 0/6/0 | 83.3% | 0.011365 |
| global | 6 | 0.708771 | 0.708771 | +0.000000 | 0/6/0 | 83.3% | 0.011365 |

Global Wilcoxon p-value: `1`.

Direct gate mean AUROC: `0.708771`; hierarchical gate mean AUROC: `0.708771`.

The old gate is reconstructed from the same run by applying the original nested rule to `support_union` and `cauchy_evidence`.
